from django.contrib import admin
from .models import Medicine

# Register your models here.

admin.site.register(Medicine)
